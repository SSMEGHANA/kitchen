import { Component } from '@angular/core';
// Metadata - Decorator
@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title: string = 'TekDemos - EMovies';
  tagline: string = 'One stop destination for all Movie buffs!'
}
