import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule} from '@angular/forms'
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MovieComponent } from './movie/movie.component';
import { HomeComponent } from './home/home.component';
import { MoviedetailComponent } from './moviedetail/moviedetail.component';
import { RatingComponent } from './rating/rating.component';
import { TransPipe } from 'src/transform-spaces.pipe';

@NgModule({
  declarations: [
    AppComponent,
    MovieComponent,
    HomeComponent,
    RatingComponent,
    MoviedetailComponent,
    TransPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }