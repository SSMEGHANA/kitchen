import { Component, OnInit, OnDestroy, OnChanges } from '@angular/core';
import { IMovies } from './movie';
import { MovieService } from './movie.service';


@Component({

    selector: 'mov-app',
    templateUrl: './movie.component.html',
    styleUrls: ['./movie.component.css']

})

export class MovieComponent implements OnInit, OnDestroy, OnChanges {

    imgWidth: number = 200;
    imgHeight: number = 150;
    imgRadius = 10;
    _searchTerm: string;
    movTitle = "Top Movies!";
    dispPic: boolean = true;
    //searchTerm='Avengers';
    searchedMovies: IMovies[];
    errorMessage: string;

    get searchTerm(): string {
        return this._searchTerm;
    }

    set searchTerm(value: string) {
        this._searchTerm = value;
        this.searchedMovies = this.searchTerm ? this.performSearch(this.searchTerm) : this.movies;
    }

    //Dependency Injection of Movie service
    constructor(private movservice: MovieService) {
    }

    ngOnInit(): void {
        this.movies = this.movservice.getMovies();
        this.searchedMovies = this.movies;

    }



    ngOnChanges(): void {
        console.log("changing up..")
    }

    ngOnDestroy(): void {
        console.log("Cleaning up..")
    }

    performSearch(searchby: string): IMovies[] {
        searchby = searchby.toLocaleLowerCase();
        return this.movies.filter((movie: IMovies) => movie.movieName.toLocaleLowerCase().indexOf(searchby) !== -1);
    }



    onRatingClicked(rate: string): void {
        this.movTitle = rate;
    }

    movies: IMovies[] = [];

    togImgMode(): void {
        this.dispPic = !this.dispPic;
    }

}


