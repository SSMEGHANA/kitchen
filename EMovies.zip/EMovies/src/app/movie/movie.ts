export interface IMovies {

    //properties
    movieID: number,
    movieName: string,
    movieStar: string,
    movieGenre: string,
    movieRating: number,
    movieImg: string
}