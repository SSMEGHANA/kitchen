import { Component,OnInit } from '@angular/core';
import { ActivatedRoute, Router } from "@angular/router";
import { IMovies } from 'src/app/movie/movie';
import { MovieService } from 'src/app/movie/movie.service';

@Component({
  selector: 'app-moviedetail',
  templateUrl: './moviedetail.component.html',
  styleUrls: ['./moviedetail.component.css']
})
export class MoviedetailComponent implements OnInit {

  pgtitle: string = "Movie Detail Page";
  movie: IMovies;
  //DI
  constructor(private router: Router, private aroute: ActivatedRoute,private movservice:MovieService) { }

  ngOnInit(): void {

    let id = +this.aroute.snapshot.paramMap.get('id');
    // alert(id);
    this.pgtitle += `:${id}`;
    this.movie = this.movservice.getMovie(id);
      

  }


  getback() {
    this.router.navigate(['/movies']);

  }

}

