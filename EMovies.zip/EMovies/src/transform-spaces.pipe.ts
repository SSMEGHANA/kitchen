import { Pipe, PipeTransform } from "@angular/core";

@Pipe({
    name: 'CustomPipe'
})
export class TransPipe implements PipeTransform {
    transform(value: string, changechar: string) {
        return value.replace(changechar, ' ');

    }

}