export class Admin{
    constructor(public email="",public password=""){

    }
}