export class Kitchens{
    constructor(public vegetableid="", public vegetablename="",public vegetablecost="", public vegetableimg="",public vo="",public vid=""){
        
    }
}