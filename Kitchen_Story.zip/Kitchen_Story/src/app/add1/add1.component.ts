import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { MyFruits } from '../fruits/fruits';
import { fruitsservice } from '../fruits/fruits.services';
import { Kitchens } from "./add1";

@Component({
  selector: 'app-add1',
  templateUrl: './add1.component.html',
  styleUrls: ['./add1.component.css']
})

export class Add1Component implements OnInit {
  vegetableid:number;
  vegetablename:string;
  vegetablecost:string;
  vegetableimg:string;
  vo:number;
  vid:number;
    kitchens:MyFruits[]=[];

    kitchen=new Kitchens();
  constructor(private fruitservice:fruitsservice, private route:Router) { }

  ngOnInit(): void {
    this.kitchens=this.fruitservice.getItems();
  }
  save(userForm:NgForm){
    alert("Form Submitted"+this.kitchen.vegetableimg);
  }
  onFruitAdd(userForm:NgForm){
    let a={
      vegetableid:+this.kitchen.vegetableid,
      vegetablename:this.kitchen.vegetablename,
      vegetablecost:this.kitchen.vegetablecost,
      vegetableimg:this.kitchen.vegetableimg,
      vo:+this.kitchen.vo,
      vid:+this.kitchen.vid

    }
    this.kitchens.push(a);
    alert("Item Added");
    this.route.navigate(['./adfruits']);    
  }

}