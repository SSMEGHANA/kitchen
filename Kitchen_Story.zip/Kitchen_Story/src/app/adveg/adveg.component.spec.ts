import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdvegComponent } from './adveg.component';

describe('AdvegComponent', () => {
  let component: AdvegComponent;
  let fixture: ComponentFixture<AdvegComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdvegComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdvegComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
