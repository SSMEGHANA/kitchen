import { Component, OnInit } from '@angular/core';
import { CartService } from 'src/cart.service';
@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
items=this.cartService.getItems();
cartTotal:number=0;
imgWidth="100";
imgHeight="100";
imgRadius="20";
qc:number=0;

  constructor(private cartService :CartService) { }

  ngOnInit(): void {
    this.cd(); 
    this.loadCart(); 
  }
  gcd:any=[];
 cd()
 {
   if(localStorage.getItem('localCart'))
   {
      this.gcd=JSON.parse(localStorage.getItem('localCart'));
   }
 }   
 Inc(vid,vegetableid)
 {
   for(let i=0;i<this.gcd.length;i++)
   {
if(this.gcd[i].vegetableid===vegetableid)
{
  this.gcd[i].vid=parseInt(vid)+1;
}
localStorage.setItem('localCart',JSON.stringify(this.gcd));
this.loadCart(); 
}
}
 Dec(vid,vegetableid)
 {
  for(let i=0;i<this.gcd.length;i++)
  {
if(this.gcd[i].vegetableid===vegetableid)
{
  if(vid>0)
 this.gcd[i].vid=parseInt(vid)-1;
}
localStorage.setItem('localCart',JSON.stringify(this.gcd));
this.loadCart();
}
 }
 total:number=0;
 loadCart()
 {
   if(localStorage.getItem('localCart'))
   {
     this.gcd=JSON.parse(localStorage.getItem('localCart'));
     this.total=this.gcd.reduce(function(acc,val){
      return acc+(val.vo*val.vid);
     },0);
   }
 }
 sd(gcdsd)
 {
   if(localStorage.getItem('localCart'))
   {
     this.gcd=JSON.parse(localStorage.getItem('localCart'));
     for(let i=0;i<this.gcd.length;i++)
     {
       if(this.gcd[i].vegetableid===gcdsd)
       {
         this.gcd.splice(i,1);
         localStorage.setItem('localCart',JSON.stringify(this.gcd));
         this.loadCart();
       }
     }
   }
 }
 re()
 {
   localStorage.removeItem('localCart');
   this.gcd=[];
   this.total=0;
 }
}