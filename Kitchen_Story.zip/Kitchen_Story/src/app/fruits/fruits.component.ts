import { Component, OnInit } from '@angular/core';
import { MyFruits } from './fruits';
import { fruitsservice } from './fruits.services'
import { Router, ActivatedRoute } from "@angular/router";

@Component({
  selector: 'app-fruits',
  templateUrl: './fruits.component.html',
  styleUrls: ['./fruits.component.css']
})
export class FruitsComponent implements OnInit {
  kitchen:MyFruits[]=[]; 
  _searchTerm:string;
  searchedItems:MyFruits[]=[];
  get searchTerm():string{
       return this._searchTerm;
        }

  set searchTerm(value:string){
    
    this._searchTerm=value;
    this.searchedItems=this.searchTerm?this.searchkitchen(this.searchTerm):this.kitchen;
   

  }
 
  
searchkitchen(searchby:string):MyFruits[]{
        searchby=searchby.toLocaleLowerCase();
        return this.kitchen.filter((movie:MyFruits)=>movie.vegetablename.toLocaleLowerCase().indexOf(searchby)!==-1);
    }


  

  
    constructor(private route: Router, private aroute: ActivatedRoute, private kitservice: fruitsservice) { }
  ngOnInit(): void {
    
    this.kitchen=this.kitservice.getItems();
    this.searchedItems=this.kitchen;
  }
Inc(kitchen) {

  this.kitservice.incItem(kitchen);
}
Dec(kitchen) {

this.kitservice.decItem(kitchen);
}
Atc(category){
this.kitservice.atc(category);
}
}
