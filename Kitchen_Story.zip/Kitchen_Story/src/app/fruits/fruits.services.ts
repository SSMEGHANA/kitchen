import { Injectable } from "@angular/core";
import { MyFruits } from "./fruits";



@Injectable({
    providedIn:'root'
})
  export class fruitsservice
  {
public Items:MyFruits[]=[
      {
            "vegetableid":101,
            "vegetablename":"Mustard seeds",
            "vegetablecost":"Rs 40 per kg",
            "vegetableimg":"../assets/ms.jpg",
            "vo":40,
            "vid":0
          },
          {
            "vegetableid": 102,
            "vegetablename":"Green Gram",
            "vegetablecost":"Rs 30 per kg",
            "vegetableimg":"../assets/greengram.jpg",
            "vo":30,
            "vid":0
          },
          {
            "vegetableid":103,
            "vegetablename":" Fenugreek Seeds",
            "vegetablecost":"Rs 30 per kg",
            "vegetableimg":"../assets/fgs.jpg",
            "vo":30,
            "vid":0
          },
          {
            "vegetableid":104,
            "vegetablename":"Black Gram",
            "vegetablecost":"Rs 20 per kg",
            "vegetableimg":"../assets/blackgram.jpg",
            "vo":20,
            "vid":0
          },
          {
            "vegetableid":105,
            "vegetablename":"Poppy Seeds",
            "vegetablecost":"Rs 10 per kg",
            "vegetableimg":"../assets/poppy.jpg",
            "vo":10,
            "vid":0
          },
          {
            "vegetableid":106,
            "vegetablename":"Coriander seeds",
            "vegetablecost":"Rs 20 per kg",
            "vegetableimg":"../assets/cors.jpg",
            "vo":20,
            "vid":0
          },
          {
            "vegetableid":107,
            "vegetablename":"Bengal Gram",
            "vegetablecost":"Rs 20 per kg",
            "vegetableimg":"../assets/Bengal-Gram.jpg",
            "vo":20,
            "vid":0
          },
          {
            "vegetableid":108,
            "vegetablename":" Cumin seeds",
            "vegetablecost":"Rs 30 per kg",
            "vegetableimg":"../assets/cus.jpg",
            "vo":30,
            "vid":0
          },
          {
            "vegetableid":109,
            "vegetablename":"Urad dal",
            "vegetablecost":"Rs 30 per kg",
            "vegetableimg":"../assets/ud.jpg",
            "vo":30,
            "vid":0
          },
          {
            "vegetableid":110,
            "vegetablename":"Ajowan",
            "vegetablecost":"Rs 20 per kg",
            "vegetableimg":"../assets/aj.jpg",
            "vo":20,
            "vid":0
          },
          {
            "vegetableid":111,
            "vegetablename":"Red Gram",
            "vegetablecost":"Rs 20 per kg",
            "vegetableimg":"../assets/redgram.jpg",
            "vo":20,
            "vid":0
          },
          {
            "vegetableid":112,
            "vegetablename":"Millet",
            "vegetablecost":"Rs 30 per kg",
            "vegetableimg":"../assets/millets.jpg",
            "vo":30,
            "vid":0
          }


    ]
    getItem(id:number):MyFruits
    {
      const it=this.getItems().find(it=>it.vegetableid===id);
      return it;
    }
      getItems():MyFruits[]{

        return this.Items;
          

      }
      incItem(Items)
      {
    Items.vid=Items.vid+1;
      }
      decItem(Items)
      {
        if(Items.vid>0)
        Items.vid=Items.vid-1;
      }
      itemsCart:any=[];
      atc(category)
      {
        console.log(category);
        let cdn=localStorage.getItem('localCart');
        if(cdn==null)
        {
          let sdg:any=[];
          sdg.push(category);
          localStorage.setItem('localCart',JSON.stringify(sdg));
        }
        else{
          var id=category.vegetableid;
          let index:number=-1;
          this.itemsCart=JSON.parse(localStorage.getItem('localCart'));
          for(let i=0;i<this.itemsCart.length;i++)
          {
            if(parseInt(id)===parseInt(this.itemsCart[i].vegetableid))
            {
              this.itemsCart[i].vid=category.vid;
              index=i;
              break;
            }
          }
          if(index==-1)
            {
              this.itemsCart.push(category);
              localStorage.setItem('localCart',JSON.stringify(this.itemsCart));
            }
            else{
              localStorage.setItem('localCart',JSON.stringify(this.itemsCart));
            }
        }
      }
  }  
    
   