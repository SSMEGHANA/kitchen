import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Fruits1Component } from './fruits1.component';

describe('Fruits1Component', () => {
  let component: Fruits1Component;
  let fixture: ComponentFixture<Fruits1Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Fruits1Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(Fruits1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
