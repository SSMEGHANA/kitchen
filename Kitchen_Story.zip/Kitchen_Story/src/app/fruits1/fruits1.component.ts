import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from "@angular/router";
import { MyFruits } from '../fruits/fruits';
import { fruitsservice } from '../fruits/fruits.services';

@Component({
  selector: 'app-fruits1',
  templateUrl: './fruits1.component.html',
  styleUrls: ['./fruits1.component.css']
})
export class Fruits1Component implements OnInit {
  kitchen:MyFruits[]=[]; 
  _searchTerm:string;
  searchedItems:MyFruits[]=[];
  get searchTerm():string{
       return this._searchTerm;
        }

  set searchTerm(value:string){
    
    this._searchTerm=value;
    this.searchedItems=this.searchTerm?this.searchkitchen(this.searchTerm):this.kitchen;
   

  }
 
  
searchkitchen(searchby:string):MyFruits[]{
        searchby=searchby.toLocaleLowerCase();
        return this.kitchen.filter((movie:MyFruits)=>movie.vegetablename.toLocaleLowerCase().indexOf(searchby)!==-1);
    }


  

  
    constructor(private route: Router, private aroute: ActivatedRoute, private kitservice: fruitsservice) { }
  ngOnInit(): void {
    
    this.kitchen=this.kitservice.getItems();
    this.searchedItems=this.kitchen;
  }
  od()
  {
  alert("Login here!");
  this.route.navigate(['/login']);
  }
}
