import { Component, OnInit} from '@angular/core';
import { Router, ActivatedRoute } from "@angular/router";
import { MyItems } from "./items";
import { itemsservice } from "./items.service";
@Component({
  selector: 'app-items',
  templateUrl: './items.component.html',
  styleUrls: ['./items.component.css']
})

export class ItemsComponent implements OnInit {
  kitchen:MyItems[]=[]; 
  _searchTerm:string;
  searchedItems:MyItems[]=[];
  string:number;
  get searchTerm():string{
       return this._searchTerm;
        }

  set searchTerm(value:string){
    
    this._searchTerm=value;
    this.searchedItems=this.searchTerm?this.searchkitchen(this.searchTerm):this.kitchen;
   

  }
 
  
searchkitchen(searchby:string):MyItems[]{
        searchby=searchby.toLocaleLowerCase();
        return this.kitchen.filter((movie:MyItems)=>movie.vegetablename.toLocaleLowerCase().indexOf(searchby)!==-1);
    }

  

constructor(private route: Router, private aroute: ActivatedRoute, private kitservice: itemsservice) { }
ngOnInit(): void {
    
    this.kitchen=this.kitservice.getItems();
    this.searchedItems=this.kitchen;
  }
  Inc(kitchen) {

      this.kitservice.incItem(kitchen);
  }
  Dec(kitchen) {

    this.kitservice.decItem(kitchen);
}
Atc(category){
  this.kitservice.atc(category);
}
}
