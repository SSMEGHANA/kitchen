import { THIS_EXPR } from "@angular/compiler/src/output/output_ast";
import { Injectable, ɵAPP_ID_RANDOM_PROVIDER } from "@angular/core";
import { MyItems } from "./items";

@Injectable({
    providedIn:'root'
})
  export class itemsservice
  {
public Items:MyItems[]=[
        {
            "vegetableid":1,
            "vegetablename":"Onion",
            "vegetablecost":"Rs 20 per kg",
            "vegetableimg":"../assets/onion.jpg",
            "vo":20,
            "vid":0
          },
          {
            "vegetableid": 2,
            "vegetablename":"Carrot",
            "vegetablecost":"Rs 30 per kg",
            "vegetableimg":"../assets/carrot.jpg",
            "vo":30,
            "vid":0
          },
          {
            "vegetableid":3,
            "vegetablename":"Brinjal",
            "vegetablecost":"Rs 20 per kg",
            "vegetableimg":"../assets/brinjal.jpg",
            "vo":20,
            "vid":0
          },
          {
            "vegetableid":4,
            "vegetablename":"Beans",
            "vegetablecost":"Rs 30 per kg",
            "vegetableimg":"../assets/beans.jpg",
            "vo":30,
            "vid":0
          },
          {
            "vegetableid":5,
            "vegetablename":"Potato",
            "vegetablecost":"Rs 10 per kg",
            "vegetableimg":"../assets/potato.jpg",
            "vo":10,
            "vid":0
          },
          {
            "vegetableid":6,
            "vegetablename":"Cabbage",
            "vegetablecost":"Rs 30 per kg",
            "vegetableimg":"../assets/cabbage.jpg",
            "vo":30,
            "vid":0
          },
          {
            "vegetableid":7,
            "vegetablename":"Cauliflower",
            "vegetablecost":"Rs 40 per kg",
            "vegetableimg":"../assets/cauliflower.jpg",
            "vo":40,
            "vid":0
          },
          {
            "vegetableid":8,
            "vegetablename":"Ladyfinger",
            "vegetablecost":"Rs 30 per kg",
            "vegetableimg":"../assets/ladyfingers.jpg",
            "vo":30,
            "vid":0
          },
          {
            "vegetableid":9,
            "vegetablename":"Tomato",
            "vegetablecost":"Rs 30 per kg",
            "vegetableimg":"../assets/tomato.jpg",
            "vo":30,
            "vid":0
          },
          {
            "vegetableid":10,
            "vegetablename":"Drumstick",
            "vegetablecost":"Rs 20 per kg",
            "vegetableimg":"../assets/drumstick.jpg",
            "vo":20,
            "vid":0
          },
          {
            "vegetableid":11,
            "vegetablename":"Gherkins",
            "vegetablecost":"Rs 30 per kg",
            "vegetableimg":"../assets/gherkins.jpg",
            "vo":30,
            "vid":0
          },
          {
            "vegetableid":12,
            "vegetablename":"Cucumber",
            "vegetablecost":"Rs 20 per kg",
            "vegetableimg":"../assets/cucumber.jpg",
            "vo":20,
            "vid":0
          }

    ]
      getItems():MyItems[]{

        return this.Items;
          

      }
      getItem(id:number):MyItems
      {
        const it=this.getItems().find(it=>it.vegetableid===id);
        return it;
      }
      incItem(Items)
      {
    Items.vid=Items.vid+1;
      }
      decItem(Items)
      {
        if(Items.vid>0)
        Items.vid=Items.vid-1;
      }
      itemsCart:any=[];
      atc(category)
      {
        console.log(category);
        let cdn=localStorage.getItem('localCart');
        if(cdn==null)
        {
          let sdg:any=[];
          sdg.push(category);
          localStorage.setItem('localCart',JSON.stringify(sdg));
        }
        else{
          var id=category.vegetableid;
          let index:number=-1;
          this.itemsCart=JSON.parse(localStorage.getItem('localCart'));
          console.log(this.itemsCart);
          for(let i=0;i<this.itemsCart.length;i++)
          {
            if(parseInt(id)===parseInt(this.itemsCart[i].vegetableid))
            {
              this.itemsCart[i].vid=category.vid;
              index=i;
              break;
            }
          }
          if(index==-1)
            {
              this.itemsCart.push(category);
              localStorage.setItem('localCart',JSON.stringify(this.itemsCart));
            }
            else{
              localStorage.setItem('localCart',JSON.stringify(this.itemsCart));
            }
        }
      }
  }  
     