import { Component, OnInit} from '@angular/core';
import { Router, ActivatedRoute } from "@angular/router";
import { MyItems } from '../items/items';
import { itemsservice } from "../items/items.service";
@Component({
  selector: 'app-items1',
  templateUrl: './items1.component.html',
  styleUrls: ['./items1.component.css']
})

export class Items1Component implements OnInit {
  kitchen:MyItems[]=[]; 
  _searchTerm:string;
  searchedItems:MyItems[]=[];
  string:number;
  get searchTerm():string{
       return this._searchTerm;
        }

  set searchTerm(value:string){
    
    this._searchTerm=value;
    this.searchedItems=this.searchTerm?this.searchkitchen(this.searchTerm):this.kitchen;
   

  }
 
  
searchkitchen(searchby:string):MyItems[]{
        searchby=searchby.toLocaleLowerCase();
        return this.kitchen.filter((movie:MyItems)=>movie.vegetablename.toLocaleLowerCase().indexOf(searchby)!==-1);
    }

  

constructor(private route: Router, private aroute: ActivatedRoute, private kitservice: itemsservice) { }
ngOnInit(): void {
    
    this.kitchen=this.kitservice.getItems();
    this.searchedItems=this.kitchen;
  }
  od()
  {
    alert("Login here!");
    this.route.navigate(['/login']);
  }
}
